# config.py
import bpy
from bpy.props import FloatVectorProperty

BL_CATEGORY = "VCT"
DEFAULT_COLOR_LAYER = "Col"
MAIN_PANEL_ID = "VCTOOLBOX_PT_main"